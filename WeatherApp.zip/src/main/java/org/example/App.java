

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class App {

    public static String getWeatherData(double latitude, double longitude) {
        String apiUrl = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude +
                "&longitude=" + longitude + "&current_weather=true";

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            int responseCode = conn.getResponseCode();
            if (responseCode != 200) {
                throw new RuntimeException("HTTP GET Request Failed. Error Code: " + responseCode);
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }

            in.close();
            conn.disconnect();

            return response.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void displayWeather(String jsonResponse) {
        if (jsonResponse == null) {
            System.out.println("No weather data available.");
            return;
        }

        JSONObject obj = new JSONObject(jsonResponse);
        JSONObject current = obj.getJSONObject("current_weather");

        System.out.println("\n=== Current Weather Report ===");
        System.out.println("Temperature: " + current.getDouble("temperature") + " °C");
        System.out.println("Wind Speed: " + current.getDouble("windspeed") + " km/h");
        System.out.println("Weather Code: " + current.getInt("weathercode"));
        System.out.println("Time: " + current.getString("time"));
    }

    public static void main(String[] args) {
        double latitude = 13.0827;   // Chennai
        double longitude = 80.2707;

        System.out.println("Fetching weather data...");
        String weatherJson = getWeatherData(latitude, longitude);
        displayWeather(weatherJson);
    }
}
